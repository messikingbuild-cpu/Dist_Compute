"""Exemple basique : matmul distribué sur tous les GPU disponibles."""

import torch

from kinvi_dist import KinviDist


def main() -> None:
    kd = KinviDist()
    print(f"GPU détectés : {kd.num_gpus}")

    x = torch.randn(4096, 4096)
    w = torch.randn(4096, 4096)

    result = kd.run(x, lambda t: torch.matmul(t, w))
    reference = torch.matmul(x, w)
    err = (result - reference).abs().max().item()
    print(f"Erreur max vs référence : {err:.2e}")
    print(f"Idle ratios : {kd.idle_ratios()}")
    kd.shutdown()


if __name__ == "__main__":
    main()
