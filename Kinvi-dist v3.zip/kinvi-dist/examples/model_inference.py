"""Exemple : inférence distribuée d'un nn.Module via kd.wrap(model)."""

import torch
import torch.nn as nn

from kinvi_dist import KinviDist


class SmallNet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(512, 2048),
            nn.GELU(),
            nn.Linear(2048, 2048),
            nn.GELU(),
            nn.Linear(2048, 512),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def main() -> None:
    kd = KinviDist()
    model = SmallNet().eval()
    dist_model = kd.wrap(model)

    batch = torch.randn(2048, 512)
    with torch.no_grad():
        out = dist_model(batch)
        ref = model(batch)
    print(f"Sortie : {tuple(out.shape)}")
    print(f"Erreur max vs référence : {(out - ref).abs().max().item():.2e}")
    kd.shutdown()


if __name__ == "__main__":
    main()
