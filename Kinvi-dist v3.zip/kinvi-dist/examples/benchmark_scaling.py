"""Benchmark de scaling : mesure et affiche le speedup réel.

Objectif : 2 GPU = ~×2 / 3 GPU = ~×3 / N GPU = ~×N.
Métrique principale : idle_time < 1% sur chaque GPU.
"""

import time

import torch

from kinvi_dist import KinviDist

SIZES = [(8192, 8192), (8192, 8192)]  # x, w


def workload(x: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
    """Charge de calcul : quelques matmuls enchaînés."""
    y = x
    for _ in range(3):
        y = torch.matmul(y, w)
    return y


def bench(n_gpus: int, x: torch.Tensor, w: torch.Tensor) -> float:
    """Mesure le temps d'exécution avec au plus ``n_gpus`` GPU."""
    kd = KinviDist()
    # Simule un cluster plus petit si demandé (mesure honnête du réel).
    kd.master.num_gpus = min(n_gpus, kd.master.num_gpus)
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    t0 = time.perf_counter()
    kd.run(x, lambda t: workload(t, w))
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    dt = time.perf_counter() - t0
    idle = kd.idle_ratios()
    kd.shutdown()
    worst = max(idle.values()) if idle else 0.0
    return dt, worst


def main() -> None:
    x, w = (torch.randn(*s) for s in SIZES)
    probe = KinviDist()
    available = probe.num_gpus
    probe.shutdown()
    print(f"GPU disponibles : {available}")
    print(f"{'GPU':>4} {'Temps (s)':>12} {'Speedup':>9} {'Idle max':>9}")

    base = None
    for n in range(1, available + 1):
        dt, worst_idle = bench(n, x, w)
        base = dt if base is None else base
        speedup = base / dt if dt > 0 else float("inf")
        print(f"{n:>4} {dt:>12.3f} {'×%.2f' % speedup:>9} {worst_idle*100:>8.2f}%")


if __name__ == "__main__":
    main()
