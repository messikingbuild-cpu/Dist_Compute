"""Tests MODULE 7 — worker."""

import torch
import torch.nn as nn
import torch.nn.functional as F

from kinvi_dist.packet import Packet, PacketStatus
from kinvi_dist.profiler import GPUProfiler
from kinvi_dist.worker import LocalWorker, TripleBuffer, execute_op


def test_execute_op_variants():
    x = torch.randn(4, 4)
    w = torch.randn(4, 4)
    # callable arbitraire
    assert torch.allclose(execute_op(lambda t: t @ w, x), x @ w)
    # torch.matmul (via functools.partial — matmul prend 2 arguments)
    import functools

    assert torch.allclose(
        execute_op(functools.partial(torch.matmul, other=w), x), x @ w
    )
    # nn.functional.*
    assert torch.allclose(execute_op(F.relu, x), F.relu(x))
    # nn.Module forward complet
    lin = nn.Linear(4, 4).eval()
    with torch.no_grad():
        assert torch.allclose(execute_op(lin, x), lin(x))


def test_triple_buffer_rotation():
    tb = TripleBuffer()
    pkts = [Packet(data=torch.zeros(2)) for _ in range(3)]
    tb.load("A", pkts[0])
    tb.load("B", pkts[1])
    tb.load("C", pkts[2])
    assert tb.active() is pkts[0]
    assert tb.prefetch_ready()
    tb.rotate()  # A fini → B devient A, C devient B
    assert tb.active() is pkts[1]
    assert not tb.prefetch_ready()  # C libéré


def test_local_worker_computes_and_profiles():
    prof = GPUProfiler(1)
    worker = LocalWorker(0, prof)
    pkt = Packet(data=torch.randn(64, 64), op=lambda t: t * 2 + 1)
    result = worker.compute(pkt)
    expected = pkt.data * 2 + 1
    assert torch.allclose(result, expected)
    assert pkt.status == PacketStatus.DONE
    assert pkt.result is result
    assert prof.t_compute(0) > 0  # T_calcul enregistré
    assert prof.idle_ratio(0) == 0.0  # aucun idle enregistré


def test_worker_heartbeat_start_stop():
    from kinvi_dist.comm import HeartbeatMonitor

    hb = HeartbeatMonitor()
    worker = LocalWorker(0, GPUProfiler(1), hb)
    worker.start_heartbeat()
    import time

    time.sleep(0.1)
    assert hb.is_alive(0)
    worker.stop_heartbeat()
