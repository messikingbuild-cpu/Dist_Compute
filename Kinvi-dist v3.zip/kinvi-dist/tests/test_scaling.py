"""Tests MODULES 8/9 — master, API et scaling.

Vérifie la règle absolue n°7 (1 GPU → overhead zéro), la reconstitution
exacte des résultats (tri par packet_id + torch.cat), et le pipeline
complet de bout en bout.
"""

import torch
import torch.nn as nn

from kinvi_dist import KinviDist
from kinvi_dist.master import Master
from kinvi_dist.monitor import Monitor


def test_single_gpu_local_zero_overhead():
    """1 GPU → calcul local direct, sans créer de packets."""
    master = Master()
    master.num_gpus = 1
    x = torch.randn(128, 128)
    w = torch.randn(128, 128)
    before = master.packets_total
    out = master.execute(x, lambda t: t @ w)
    assert master.packets_total == before  # aucun packet créé
    assert torch.allclose(out, x @ w, atol=1e-4)
    master.shutdown()


def test_distributed_result_matches_reference():
    """Le résultat concaténé doit être exactement le résultat séquentiel."""
    master = Master()
    master.num_gpus = 3  # simule 3 GPU logiques (compute local réel)
    master.profiler = type(master.profiler)(3)
    from kinvi_dist.scheduler import Scheduler
    from kinvi_dist.work_stealer import WorkStealer
    from kinvi_dist.worker import LocalWorker

    master.scheduler = Scheduler(master.profiler, [0, 1, 2])
    master.stealer = WorkStealer(master.pool, [0, 1, 2])
    master.workers = {
        i: LocalWorker(i, master.profiler, master.heartbeat) for i in range(3)
    }

    torch.manual_seed(0)
    x = torch.randn(257, 64)  # taille non divisible exprès
    w = torch.randn(64, 64)
    out = master.execute(x, lambda t: t @ w)
    ref = x @ w
    assert out.shape == ref.shape
    assert torch.allclose(out.cpu(), ref, atol=1e-4)
    assert master.packets_total >= 3
    master.shutdown()


def test_api_run_wrap_distribute_session():
    kd = KinviDist()
    x = torch.randn(32, 32)

    out = kd.run(x, lambda t: t * 3)
    assert torch.allclose(out, x * 3)

    model = nn.Linear(32, 16).eval()
    dist_model = kd.wrap(model)
    with torch.no_grad():
        assert torch.allclose(dist_model(x), model(x), atol=1e-5)

    @kd.distribute
    def heavy(t):
        return t + 1

    assert torch.allclose(heavy(x), x + 1)

    with kd.session() as s:
        r1 = s.run(x, lambda t: t.sum(dim=1))
        r2 = s.run(x, lambda t: t.mean(dim=1))
    assert r1.shape == (32,)
    assert r2.shape == (32,)

    assert isinstance(kd.idle_ratios(), dict)
    kd.shutdown()


def test_monitor_renders_dashboard():
    kd = KinviDist()
    mon = Monitor(kd.master)
    text = mon.render()
    assert "KINVI-DIST" in text
    assert "GPU 0" in text
    assert "Packets total" in text
    assert "Idle" in text
    kd.shutdown()
