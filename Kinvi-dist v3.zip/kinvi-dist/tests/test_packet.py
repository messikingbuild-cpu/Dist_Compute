"""Tests MODULE 2 — packet."""

import threading

import torch

from kinvi_dist.packet import (
    Packet,
    PacketIDGenerator,
    PacketPool,
    PacketStatus,
)


def test_id_generator_unique_threadsafe():
    gen = PacketIDGenerator()
    ids = []
    lock = threading.Lock()

    def grab():
        with lock:
            ids.append(gen.next())

    threads = [threading.Thread(target=grab) for _ in range(500)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(set(ids)) == 500  # jamais de doublon


def test_packet_lifecycle_and_timestamps():
    pkt = Packet(data=torch.randn(4, 4), op=lambda t: t * 2, gpu_target=1)
    assert pkt.packet_id > 0
    assert pkt.status == PacketStatus.PENDING
    pkt.mark_sent()
    assert pkt.status == PacketStatus.IN_TRANSIT
    pkt.mark_received()
    assert pkt.status == PacketStatus.COMPUTING
    pkt.mark_done(torch.zeros(1))
    assert pkt.status == PacketStatus.DONE
    assert pkt.compute_time >= 0.0
    assert pkt.transfer_time >= 0.0
    pkt.mark_stolen(2)
    assert pkt.status == PacketStatus.STOLEN
    assert pkt.gpu_target == 2


def test_packet_size_bytes():
    pkt = Packet(data=torch.zeros(1024, 1024, dtype=torch.float32))
    assert pkt.size_bytes == 4 * 1024 * 1024  # 4 MB


def test_pool_threadsafe_fifo():
    pool = PacketPool()
    packets = [Packet(data=torch.zeros(2)) for _ in range(100)]

    def producer():
        for p in packets:
            pool.put(p)

    threads = [threading.Thread(target=producer) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(pool) == 400
    assert pool.total_created == 400

    out = []
    while True:
        p = pool.get()
        if p is None:
            break
        out.append(p)
    assert len(out) == 400
    assert len(pool) == 0


def test_pool_steal_from_other_pool():
    a, b = PacketPool(), PacketPool()
    p1 = Packet(data=torch.zeros(2), gpu_target=0)
    p2 = Packet(data=torch.zeros(2), gpu_target=0)
    a.put(p1)
    a.put(p2)
    stolen = b.steal_from(a)
    assert stolen is p2  # dernier = pas encore transféré
    assert stolen.status == PacketStatus.STOLEN
    assert len(a) == 1
    assert len(b) == 1
