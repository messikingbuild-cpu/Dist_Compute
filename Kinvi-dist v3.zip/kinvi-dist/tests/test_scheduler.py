"""Tests MODULE 4 — scheduler."""

from kinvi_dist.profiler import GPUProfiler
from kinvi_dist.scheduler import (
    LEAD_TIME_MARGIN_S,
    MAX_PACKET_BYTES,
    MIN_PACKET_BYTES,
    SAFETY_FACTOR,
    Scheduler,
    clamp,
)


def make_scheduler(t_compute=0.010, bw=10e9):
    prof = GPUProfiler(2)
    for _ in range(10):
        prof.record_compute(0, t_compute)
        prof.record_compute(1, t_compute * 2)
        prof.record_transfer(0, 0.005, int(bw * 0.005))
        prof.record_transfer(1, 0.005, int(bw * 0.005))
    return Scheduler(prof, [0, 1]), prof


def test_clamp():
    assert clamp(5, 1, 10) == 5
    assert clamp(-1, 1, 10) == 1
    assert clamp(99, 1, 10) == 10


def test_optimal_packet_size_formula():
    sched, _ = make_scheduler(t_compute=0.010, bw=10e9)
    size = sched.optimal_packet_size(0)
    expected = int(10e9 * 0.010 * SAFETY_FACTOR)
    assert size == max(MIN_PACKET_BYTES, min(MAX_PACKET_BYTES, expected))


def test_packet_size_clamped():
    sched, _ = make_scheduler(t_compute=100.0, bw=1e12)  # taille énorme
    assert sched.optimal_packet_size(0) == MAX_PACKET_BYTES
    sched2, _ = make_scheduler(t_compute=1e-9, bw=1.0)  # taille minuscule
    assert sched2.optimal_packet_size(0) == MIN_PACKET_BYTES


def test_no_measurement_returns_min():
    sched = Scheduler(GPUProfiler(1), [0])
    assert sched.optimal_packet_size(0) == MIN_PACKET_BYTES  # mesure d'abord


def test_lead_time_formula():
    sched, _ = make_scheduler()
    lead = sched.lead_time(0)
    assert abs(lead - (0.005 + LEAD_TIME_MARGIN_S)) < 1e-3


def test_shares_favor_faster_gpu():
    sched, _ = make_scheduler()  # GPU 0 = 2× plus rapide que GPU 1
    shares = sched.compute_shares()
    assert abs(shares[0] + shares[1] - 1.0) < 1e-9
    assert shares[0] > shares[1]
    assert abs(shares[0] - 2 / 3) < 1e-3  # speed ∝ 1/T


def test_shares_equal_without_measurements():
    sched = Scheduler(GPUProfiler(3), [0, 1, 2])
    shares = sched.compute_shares()
    assert all(abs(v - 1 / 3) < 1e-9 for v in shares.values())


def test_refresh_and_loop_start_stop():
    sched, _ = make_scheduler()
    sched.start()
    sched.refresh()
    assert sched.packet_size(0) >= MIN_PACKET_BYTES
    sched.stop()
