"""Tests MODULE 6 — comm."""

import time

import torch

from kinvi_dist.comm import (
    CommBackend,
    HeartbeatMonitor,
    HEARTBEAT_DEAD_AFTER_S,
    Redistributor,
    TransferHandle,
)
from kinvi_dist.packet import Packet, PacketStatus
from kinvi_dist.profiler import GPUProfiler


def test_cpu_transfer_completes_immediately():
    comm = CommBackend(interconnect="PCIe", profiler=GPUProfiler(1))
    pkt = Packet(data=torch.randn(8, 8), gpu_target=0)
    handle = comm.send(pkt, dst_device=0)
    assert isinstance(handle, TransferHandle)
    assert handle.is_done()  # mode CPU : synchrone
    assert pkt.status in (PacketStatus.IN_TRANSIT, PacketStatus.COMPUTING)
    assert comm.complete(handle)
    assert pkt.status == PacketStatus.COMPUTING
    assert comm.profiler.t_transfer(0) >= 0.0


def test_retry_then_master_fallback():
    comm = CommBackend(profiler=GPUProfiler(1))
    pkt = Packet(data=torch.zeros(4), gpu_target=1)

    class FailingHandle:
        def __init__(self, p):
            self.packet = p

        def wait(self, timeout=30.0):
            return False  # timeout simulé

    # Force send() à échouer aussi.
    original_send = comm.send
    comm.send = lambda p, d, src_device=0: FailingHandle(p)
    try:
        ok = comm.complete(FailingHandle(pkt))
    finally:
        comm.send = original_send
    assert not ok
    assert pkt.retry_count == 4  # 1 tentative + 3 retransmissions


def test_heartbeat_lifecycle():
    hb = HeartbeatMonitor()
    assert not hb.is_alive(0)  # jamais vu → pas vivant
    hb.beat(0)
    assert hb.is_alive(0)
    assert hb.dead_workers() == []
    # Simule un silence > 2 s.
    hb._last_seen[0] = time.perf_counter() - (HEARTBEAT_DEAD_AFTER_S + 1)
    assert not hb.is_alive(0)
    assert hb.dead_workers() == [0]
    hb.unregister(0)
    assert hb.dead_workers() == []


def test_redistributor_calls_master():
    calls = []
    red = Redistributor(on_redistribute=calls.append)
    red.handle_dead(3)
    assert calls == [3]
