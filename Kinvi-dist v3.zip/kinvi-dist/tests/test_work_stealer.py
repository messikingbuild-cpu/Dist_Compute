"""Tests MODULE 5 — work_stealer."""

import torch

from kinvi_dist.packet import Packet, PacketPool
from kinvi_dist.work_stealer import LOCAL_QUEUE_MAX, WorkStealer


def _pkt():
    return Packet(data=torch.zeros(4))


def test_feed_empty_queue_takes_from_pool():
    pool = PacketPool()
    stealer = WorkStealer(pool, [0, 1])
    pool.put(_pkt())
    pkt = stealer.feed(1)
    assert pkt is not None
    assert pkt.gpu_target == 1  # mis à jour
    assert len(pool) == 0


def test_feed_skips_when_queue_not_empty():
    pool = PacketPool()
    stealer = WorkStealer(pool, [0, 1])
    pool.put(_pkt())
    stealer.queues[0].push(_pkt())  # queue déjà remplie
    assert stealer.feed(0) is None
    assert len(pool) == 1


def test_feed_returns_none_when_pool_empty():
    stealer = WorkStealer(PacketPool(), [0])
    assert stealer.feed(0) is None


def test_rebalance_moves_from_overflow_to_empty():
    pool = PacketPool()
    stealer = WorkStealer(pool, [0, 1])
    for _ in range(LOCAL_QUEUE_MAX + 2):
        stealer.queues[0].push(_pkt())
    moved = stealer.rebalance()
    assert moved, "au moins un packet déplacé"
    for pkt, src, dst in moved:
        assert src == 0 and dst == 1
        assert pkt.gpu_target == 1
    # Un packet déplacé par queue vide (spec : dernier non transféré → j).
    assert len(moved) == 1
    assert len(stealer.queues[0]) == LOCAL_QUEUE_MAX + 1
    assert stealer.steal_count == len(moved)


def test_rebalance_noop_without_empty_queue():
    pool = PacketPool()
    stealer = WorkStealer(pool, [0, 1])
    for _ in range(LOCAL_QUEUE_MAX + 2):
        stealer.queues[0].push(_pkt())
    stealer.queues[1].push(_pkt())
    assert stealer.rebalance() == []


def test_next_for_prefers_local_then_pool():
    pool = PacketPool()
    stealer = WorkStealer(pool, [0])
    local = _pkt()
    stealer.queues[0].push(local)
    assert stealer.next_for(0) is local
    pool.put(_pkt())
    assert stealer.next_for(0) is not None  # pioche le pool
    assert stealer.next_for(0) is None  # plus rien
