"""Tests MODULE 1 — detector."""

import torch

from kinvi_dist.detector import BandwidthMatrix, GPUDetector


def test_detect_returns_list_and_roles():
    det = GPUDetector()
    gpus = det.detect()
    assert isinstance(gpus, list)
    if torch.cuda.is_available() and gpus:
        assert gpus[0].role == "MASTER"
        assert all(g.role == "WORKER" for g in gpus[1:])
        assert all(g.vram_total_bytes > 0 for g in gpus)
        assert all(g.interconnect in ("NVLink", "PCIe") for g in gpus)
    else:
        assert gpus == []


def test_master_and_workers_properties():
    det = GPUDetector()
    det.detect()
    if det.gpus:
        assert det.master is det.gpus[0]
        assert det.workers == det.gpus[1:]
    else:
        assert det.master is None
        assert det.workers == []


def test_bandwidth_matrix_get_set():
    m = BandwidthMatrix()
    m.set(1, 2, 12.5e9)
    assert m.get(1, 2) == 12.5e9
    assert m.get(5, 5) == 0.0  # hors bornes → 0, pas d'exception


def test_benchmark_on_empty_cluster():
    det = GPUDetector()
    det.gpus = []
    bw = det.benchmark_bandwidth()
    assert bw.matrix == []
