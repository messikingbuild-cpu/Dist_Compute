"""KINVI-DIST — installation."""

from setuptools import find_packages, setup

setup(
    name="kinvi-dist",
    version="1.0.0",
    description=(
        "Framework de calcul distribué multi-GPU open source optimisé pour l'IA. "
        "Règle centrale : T_transfert(N+1) <= T_calcul(N)."
    ),
    author="KINVI",
    license="MIT",
    python_requires=">=3.9",
    packages=find_packages(exclude=("tests", "examples")),
    install_requires=[
        "torch>=2.0.0",
        "pynvml>=11.5",
    ],
    extras_require={"dev": ["pytest>=7.0"]},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
