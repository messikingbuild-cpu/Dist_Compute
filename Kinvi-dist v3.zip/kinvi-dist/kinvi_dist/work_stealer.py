"""MODULE 5 — Work stealing entre GPU.

Chaque worker a une queue locale de 2-3 packets. Si la queue d'un GPU
se vide et que le PacketPool global n'est pas vide, il prend le prochain
packet immédiatement. Si une queue déborde (>3) pendant qu'une autre
est vide, le dernier packet non transféré est déplacé.
"""

from __future__ import annotations

import threading
from typing import Dict, List, Optional

from .packet import Packet, PacketPool

LOCAL_QUEUE_MAX: int = 3


class LocalQueue:
    """Queue locale d'un worker (2-3 packets), thread-safe."""

    def __init__(self, gpu_index: int) -> None:
        self.gpu_index = gpu_index
        self._items: List[Packet] = []
        self._lock = threading.Lock()

    def push(self, pkt: Packet) -> None:
        with self._lock:
            self._items.append(pkt)

    def pop(self) -> Optional[Packet]:
        with self._lock:
            return self._items.pop(0) if self._items else None

    def pop_last(self) -> Optional[Packet]:
        """Retire le dernier packet (le moins avancé, volable)."""
        with self._lock:
            return self._items.pop() if self._items else None

    def __len__(self) -> int:
        with self._lock:
            return len(self._items)

    def is_empty(self) -> bool:
        return len(self) == 0


class WorkStealer:
    """Équilibre les packets entre le pool global et les queues locales."""

    def __init__(self, global_pool: PacketPool, gpu_indices: List[int]) -> None:
        self.global_pool = global_pool
        self.queues: Dict[int, LocalQueue] = {
            i: LocalQueue(i) for i in gpu_indices
        }
        self._lock = threading.Lock()
        self._steal_count: int = 0

    # ------------------------------------------------------------------
    def feed(self, gpu: int) -> Optional[Packet]:
        """Si queue_locale[gpu] vide ET pool non vide → prendre et lancer.

        Met à jour ``packet.gpu_target`` et retourne le packet à
        transférer immédiatement.
        """
        q = self.queues[gpu]
        if not q.is_empty():
            return None
        pkt = self.global_pool.get()
        if pkt is None:
            return None
        pkt.gpu_target = gpu
        q.push(pkt)
        return pkt

    def rebalance(self) -> List[tuple]:
        """Déplace les packets des queues >3 vers les queues vides.

        Returns:
            Liste de (packet, gpu_source, gpu_dest) déplacés.
        """
        moved: List[tuple] = []
        with self._lock:
            empties = [i for i, q in self.queues.items() if q.is_empty()]
            if not empties:
                return moved
            for i, q in self.queues.items():
                while len(q) > LOCAL_QUEUE_MAX and empties:
                    dest = empties[0]
                    pkt = q.pop_last()
                    if pkt is None:
                        break
                    pkt.gpu_target = dest
                    self.queues[dest].push(pkt)
                    self._steal_count += 1
                    moved.append((pkt, i, dest))
                    if not self.queues[dest].is_empty():
                        empties.pop(0)
        return moved

    # ------------------------------------------------------------------
    def next_for(self, gpu: int) -> Optional[Packet]:
        """Prochain packet à calculer pour ce GPU (queue locale d'abord)."""
        pkt = self.queues[gpu].pop()
        if pkt is not None:
            return pkt
        # Queue vide : alimenter depuis le pool puis retirer le packet.
        if self.feed(gpu) is not None:
            return self.queues[gpu].pop()
        return None

    def submit(self, pkt: Packet) -> None:
        """Soumet un packet (pool global)."""
        self.global_pool.put(pkt)

    @property
    def steal_count(self) -> int:
        with self._lock:
            return self._steal_count
