"""KINVI-DIST — Framework de calcul distribué multi-GPU optimisé pour l'IA.

Règle physique centrale : T_transfert(packet N+1) ≤ T_calcul(packet N).
Si cette condition tient → GPU idle time < 1% → scaling parfait.

Usage::

    from kinvi_dist import KinviDist
    kd = KinviDist()
    result = kd.run(tensor, op)
"""

from .api import KinviDist
from .detector import BandwidthMatrix, GPUDetector, GPUInfo
from .master import Master
from .monitor import Monitor
from .packet import Packet, PacketIDGenerator, PacketPool, PacketStatus
from .profiler import ExpAvg, GPUProfiler, GPUStats
from .scheduler import Scheduler
from .work_stealer import LocalQueue, WorkStealer

__version__ = "1.0.0"

__all__ = [
    "KinviDist",
    "Master",
    "Monitor",
    "GPUDetector",
    "GPUInfo",
    "BandwidthMatrix",
    "Packet",
    "PacketPool",
    "PacketStatus",
    "PacketIDGenerator",
    "GPUProfiler",
    "GPUStats",
    "ExpAvg",
    "Scheduler",
    "WorkStealer",
    "LocalQueue",
    "__version__",
]
