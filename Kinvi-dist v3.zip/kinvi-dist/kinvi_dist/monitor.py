"""MODULE 10 — Dashboard CLI rafraîchi toutes les 200 ms."""

from __future__ import annotations

import shutil
import threading
from typing import Optional

from .master import Master
from .utils import format_bw, format_bytes, format_ms

REFRESH_S: float = 0.2
BAR_WIDTH: int = 10


def _bar(ratio: float, width: int = BAR_WIDTH) -> str:
    filled = int(round(max(0.0, min(1.0, ratio)) * width))
    return "█" * filled + "░" * (width - filled)


class Monitor:
    """Dashboard CLI temps réel du cluster KINVI-DIST."""

    def __init__(self, master: Master, refresh_s: float = REFRESH_S) -> None:
        self.master = master
        self.refresh_s = refresh_s
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------
    def render(self) -> str:
        """Rend le dashboard en texte (testable sans terminal)."""
        snap = self.master.profiler.snapshot()
        lines = []
        w = 46
        lines.append("╔" + "═" * w + "╗")
        lines.append("║" + "KINVI-DIST  v1.0".center(w) + "║")
        lines.append("╠" + "═" * w + "╣")
        for gpu, st in sorted(snap.items()):
            role = "MASTER" if gpu == 0 else "WORKER"
            idle = st["idle_ratio"]
            busy = 1.0 - idle
            line1 = f" GPU {gpu} {role}  {_bar(busy)}  {busy*100:3.0f}%"
            lines.append("║" + line1.ljust(w) + "║")
            line2 = (
                f"  Compute : {format_ms(st['t_compute'])}/pkt │ "
                f"BW : {format_bw(st['bandwidth'])}"
            )
            lines.append("║" + line2.ljust(w)[:w] + "║")
            pkt = format_bytes(self.master.scheduler.packet_size(gpu))
            line3 = f"  Packet size : {pkt} (auto) │ Idle : {idle*100:.1f}%"
            lines.append("║" + line3.ljust(w)[:w] + "║")
            lines.append("╠" + "═" * w + "╣")
        foot = (
            f" Packets total : {self.master.packets_total}"
            f"  │ Stolen : {self.master.packets_stolen}"
        )
        lines.append("║" + foot.ljust(w)[:w] + "║")
        lines.append("╚" + "═" * w + "╝")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    def _loop(self) -> None:
        while not self._stop.is_set():
            if shutil.get_terminal_size((80, 24)).columns > 40:
                print("\033[2J\033[H" + self.render(), flush=True)
            self._stop.wait(self.refresh_s)

    def start(self) -> None:
        """Démarre le rafraîchissement toutes les 200 ms (daemon)."""
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="kinvi-monitor", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def __enter__(self) -> "Monitor":
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.stop()
