"""MODULE 4 — Scheduler CPU léger.

Boucle toutes les 5 ms, ne bloque jamais les GPU. Calcule :
  - la taille optimale des packets : bandwidth[i] * T_calcul[i] * 0.85
  - le lead time : quand envoyer le prochain packet
  - le load balancing dynamique proportionnel à 1 / T_calcul[i]

RÈGLE PHYSIQUE CENTRALE : T_transfert(N+1) ≤ T_calcul(N).
"""

from __future__ import annotations

import threading
import time
from typing import Dict, List, Optional

from .profiler import GPUProfiler

MIN_PACKET_BYTES: int = 1 * 1024**2  # 1 MB
MAX_PACKET_BYTES: int = 512 * 1024**2  # 512 MB
SAFETY_FACTOR: float = 0.85
SCHEDULER_PERIOD_S: float = 0.005  # 5 ms
LEAD_TIME_MARGIN_S: float = 0.002  # 2 ms


def clamp(value: float, lo: float, hi: float) -> float:
    """Clamp ``value`` dans [lo, hi]."""
    return max(lo, min(hi, value))


class Scheduler:
    """Ordonnanceur central — mesure avant d'ajuster, jamais de hardcodé."""

    def __init__(self, profiler: GPUProfiler, gpu_indices: List[int]) -> None:
        self.profiler = profiler
        self.gpu_indices = list(gpu_indices)
        self._lock = threading.Lock()
        self._packet_sizes: Dict[int, int] = {
            i: MIN_PACKET_BYTES for i in self.gpu_indices
        }
        self._t_start_compute: Dict[int, float] = {}
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------
    def optimal_packet_size(self, gpu: int) -> int:
        """Taille optimale : bandwidth * T_calcul * 0.85, clampée 1MB–512MB.

        Tant que le profiler n'a pas de mesure, retourne le minimum
        (le scheduler mesure avant d'ajuster).
        """
        bw = self.profiler.bandwidth(gpu)
        t_calc = self.profiler.t_compute(gpu)
        if bw <= 0 or t_calc <= 0:
            return MIN_PACKET_BYTES
        optimal = bw * t_calc * SAFETY_FACTOR
        return int(clamp(optimal, MIN_PACKET_BYTES, MAX_PACKET_BYTES))

    # ------------------------------------------------------------------
    def lead_time(self, gpu: int) -> float:
        """lead_time[i] = T_transfer[i] + 2 ms."""
        return self.profiler.t_transfer(gpu) + LEAD_TIME_MARGIN_S

    def send_at(self, gpu: int) -> float:
        """Instant d'envoi du prochain packet (perf_counter).

        send_at = t_start_compute[i] + T_calcul[i] - lead_time[i]
        """
        with self._lock:
            t_start = self._t_start_compute.get(gpu, time.perf_counter())
        t_calc = self.profiler.t_compute(gpu)
        return t_start + t_calc - self.lead_time(gpu)

    def notify_compute_started(self, gpu: int) -> None:
        """Appelé par le worker au démarrage d'un calcul."""
        with self._lock:
            self._t_start_compute[gpu] = time.perf_counter()

    # ------------------------------------------------------------------
    def compute_shares(self) -> Dict[int, float]:
        """Load balancing : share[i] = speed[i] / Σspeed, speed = 1/T_calcul.

        GPU sans mesure reçoivent une part égale par défaut.
        """
        speeds: Dict[int, float] = {}
        for i in self.gpu_indices:
            t = self.profiler.t_compute(i)
            speeds[i] = 1.0 / t if t > 0 else 0.0

        measured = {i: s for i, s in speeds.items() if s > 0}
        if len(measured) < len(self.gpu_indices):
            n = max(len(self.gpu_indices), 1)
            return {i: 1.0 / n for i in self.gpu_indices}

        total = sum(measured.values())
        return {i: s / total for i, s in measured.items()}

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        """Recalcule les tailles de packets pour tous les GPU."""
        with self._lock:
            for i in self.gpu_indices:
                self._packet_sizes[i] = self.optimal_packet_size(i)

    def packet_size(self, gpu: int) -> int:
        with self._lock:
            return self._packet_sizes.get(gpu, MIN_PACKET_BYTES)

    # ------------------------------------------------------------------
    def _loop(self) -> None:
        """Boucle 5 ms — ne bloque jamais les GPU (thread dédié)."""
        while not self._stop.is_set():
            try:
                self.refresh()
            except Exception:
                pass  # le scheduler ne doit jamais crasher le pipeline
            self._stop.wait(SCHEDULER_PERIOD_S)

    def start(self) -> None:
        """Démarre la boucle du scheduler (thread léger, daemon)."""
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="kinvi-scheduler", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        """Arrête la boucle."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def __enter__(self) -> "Scheduler":
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.stop()
