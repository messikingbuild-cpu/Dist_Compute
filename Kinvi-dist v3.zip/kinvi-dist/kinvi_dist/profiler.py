"""MODULE 3 — Profiler temps réel par GPU (thread-safe).

Mesure en continu T_calcul, T_transfer, bandwidth et idle_time par GPU,
avec moyennes exponentielles : valeur = 0.8 * précédente + 0.2 * mesure.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Dict

ALPHA: float = 0.2  # poids de la mesure actuelle
WINDOW: int = 10  # nombre de mesures retenues


class ExpAvg:
    """Moyenne exponentielle glissante (0.8/0.2), thread-safe."""

    def __init__(self, alpha: float = ALPHA, window: int = WINDOW) -> None:
        self.alpha = alpha
        self.window = window
        self._value: float = 0.0
        self._count: int = 0
        self._lock = threading.Lock()

    def update(self, measure: float) -> float:
        """Intègre une mesure et retourne la nouvelle moyenne."""
        with self._lock:
            if self._count == 0:
                self._value = measure
            else:
                self._value = (
                    (1.0 - self.alpha) * self._value + self.alpha * measure
                )
            self._count = min(self._count + 1, self.window)
            return self._value

    @property
    def value(self) -> float:
        with self._lock:
            return self._value

    @property
    def warmed_up(self) -> bool:
        """True si au moins une mesure a été intégrée."""
        with self._lock:
            return self._count > 0


@dataclass
class GPUStats:
    """Statistiques temps réel d'un GPU."""

    t_compute: ExpAvg = field(default_factory=ExpAvg)
    t_transfer: ExpAvg = field(default_factory=ExpAvg)
    bandwidth: ExpAvg = field(default_factory=ExpAvg)  # octets/s
    _idle_total: float = 0.0
    _active_total: float = 0.0
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def record_idle(self, seconds: float) -> None:
        with self._lock:
            self._idle_total += max(0.0, seconds)

    def record_active(self, seconds: float) -> None:
        with self._lock:
            self._active_total += max(0.0, seconds)

    @property
    def idle_ratio(self) -> float:
        """idle_time / temps total (objectif : < 1%)."""
        with self._lock:
            total = self._idle_total + self._active_total
            return self._idle_total / total if total > 0 else 0.0


class GPUProfiler:
    """Profiler global thread-safe, indexé par GPU."""

    def __init__(self, num_gpus: int) -> None:
        self._stats: Dict[int, GPUStats] = {
            i: GPUStats() for i in range(num_gpus)
        }
        self._lock = threading.Lock()
        self._t_start: float = time.perf_counter()

    # ------------------------------------------------------------------
    def _ensure(self, gpu: int) -> GPUStats:
        with self._lock:
            if gpu not in self._stats:
                self._stats[gpu] = GPUStats()
            return self._stats[gpu]

    # ------------------------------------------------------------------
    def record_compute(self, gpu: int, seconds: float) -> None:
        """Enregistre un T_calcul mesuré."""
        st = self._ensure(gpu)
        st.t_compute.update(seconds)
        st.record_active(seconds)

    def record_transfer(self, gpu: int, seconds: float, size_bytes: int) -> None:
        """Enregistre un T_transfert mesuré + bande passante dérivée."""
        st = self._ensure(gpu)
        st.t_transfer.update(seconds)
        if seconds > 0:
            st.bandwidth.update(size_bytes / seconds)

    def record_idle(self, gpu: int, seconds: float) -> None:
        """Enregistre du temps d'attente GPU."""
        self._ensure(gpu).record_idle(seconds)

    # ------------------------------------------------------------------
    def t_compute(self, gpu: int) -> float:
        return self._ensure(gpu).t_compute.value

    def t_transfer(self, gpu: int) -> float:
        return self._ensure(gpu).t_transfer.value

    def bandwidth(self, gpu: int) -> float:
        return self._ensure(gpu).bandwidth.value

    def idle_ratio(self, gpu: int) -> float:
        return self._ensure(gpu).idle_ratio

    @property
    def uptime(self) -> float:
        return time.perf_counter() - self._t_start

    @property
    def num_gpus(self) -> int:
        with self._lock:
            return len(self._stats)

    def snapshot(self) -> Dict[int, Dict[str, float]]:
        """Vue instantanée de toutes les métriques (pour le monitor)."""
        with self._lock:
            items = list(self._stats.items())
        return {
            gpu: {
                "t_compute": st.t_compute.value,
                "t_transfer": st.t_transfer.value,
                "bandwidth": st.bandwidth.value,
                "idle_ratio": st.idle_ratio,
            }
            for gpu, st in items
        }
