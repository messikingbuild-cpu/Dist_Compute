"""MODULE 9 — API publique KINVI-DIST.

Usage::

    from kinvi_dist import KinviDist
    kd = KinviDist()
    result = kd.run(tensor, op)
    model  = kd.wrap(model)

    @kd.distribute
    def heavy(tensor): ...

    with kd.session() as s:
        r1 = s.run(t1, op1)
        r2 = s.run(t2, op2)
"""

from __future__ import annotations

import functools
from typing import Callable, Optional

import torch
import torch.nn as nn

from .master import Master
from .monitor import Monitor


class _DistributedModel(nn.Module):
    """``nn.Module`` enveloppé : forward distribué via le Master."""

    def __init__(self, model: nn.Module, master: Master) -> None:
        super().__init__()
        self.model = model
        self._master = master

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self._master.execute(x, self.model)


class _Session:
    """Session : réutilise le même Master (mesures chaudes) entre runs."""

    def __init__(self, kd: "KinviDist") -> None:
        self._kd = kd

    def run(self, tensor: torch.Tensor, op: Callable) -> torch.Tensor:
        return self._kd.run(tensor, op)

    def __enter__(self) -> "_Session":
        return self

    def __exit__(self, *exc: object) -> None:
        pass


class KinviDist:
    """Point d'entrée du framework de calcul distribué multi-GPU."""

    def __init__(self, monitor: bool = False) -> None:
        self.master = Master()
        self._monitor: Optional[Monitor] = None
        if monitor:
            self._monitor = Monitor(self.master)
            self._monitor.start()

    # ------------------------------------------------------------------
    def run(self, tensor: torch.Tensor, op: Callable) -> torch.Tensor:
        """Exécute ``op`` sur ``tensor`` distribué sur tous les GPU."""
        return self.master.execute(tensor, op)

    def wrap(self, model: nn.Module) -> nn.Module:
        """Enveloppe un modèle : chaque forward est distribué."""
        return _DistributedModel(model, self.master)

    def distribute(self, fn: Callable) -> Callable:
        """Décorateur : la fonction décorée s'exécute de façon distribuée."""

        @functools.wraps(fn)
        def wrapper(tensor: torch.Tensor, *args, **kwargs) -> torch.Tensor:
            op = lambda t: fn(t, *args, **kwargs)  # noqa: E731
            return self.master.execute(tensor, op)

        return wrapper

    def session(self) -> _Session:
        """Ouvre une session de runs consécutifs."""
        return _Session(self)

    # ------------------------------------------------------------------
    @property
    def num_gpus(self) -> int:
        return self.master.num_gpus

    def idle_ratios(self) -> dict:
        """idle_time par GPU (objectif : < 1%)."""
        return self.master.idle_ratios()

    def shutdown(self) -> None:
        """Arrêt propre du framework."""
        if self._monitor is not None:
            self._monitor.stop()
            self._monitor = None
        self.master.shutdown()

    def __enter__(self) -> "KinviDist":
        return self

    def __exit__(self, *exc: object) -> None:
        self.shutdown()
