"""MODULE 2 — Packet, générateur d'IDs atomique et PacketPool thread-safe."""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Deque, Optional

import torch


class PacketStatus(Enum):
    """Cycle de vie d'un packet."""

    PENDING = auto()
    IN_TRANSIT = auto()
    COMPUTING = auto()
    DONE = auto()
    STOLEN = auto()


class PacketIDGenerator:
    """Compteur atomique thread-safe — jamais de doublon d'ID."""

    def __init__(self, start: int = 0) -> None:
        self._value: int = start
        self._lock = threading.Lock()

    def next(self) -> int:
        """Retourne le prochain ID unique."""
        with self._lock:
            self._value += 1
            return self._value


# Générateur global partagé.
GLOBAL_ID_GENERATOR = PacketIDGenerator()


@dataclass
class Packet:
    """Unité de travail transférable entre GPU.

    Attributes:
        packet_id: ID unique (via ``PacketIDGenerator``).
        gpu_target: Index du GPU destinataire.
        data: Tensor (pinned memory obligatoire si CPU).
        op: Callable appliqué au tensor par le worker.
        status: État courant du cycle de vie.
        t_created, t_sent, t_received, t_done: Horodatages (perf_counter).
        retry_count: Nombre de retransmissions déjà tentées.
    """

    data: torch.Tensor
    op: Optional[Callable[[torch.Tensor], torch.Tensor]] = None
    gpu_target: int = -1
    packet_id: int = field(default_factory=GLOBAL_ID_GENERATOR.next)
    status: PacketStatus = PacketStatus.PENDING
    t_created: float = field(default_factory=time.perf_counter)
    t_sent: float = 0.0
    t_received: float = 0.0
    t_done: float = 0.0
    retry_count: int = 0
    result: Optional[torch.Tensor] = None

    def __post_init__(self) -> None:
        # Pinned memory obligatoire pour tout tensor CPU en transit.
        if (
            not self.data.is_cuda
            and torch.cuda.is_available()
            and not self.data.is_pinned()
        ):
            self.data = self.data.pin_memory()

    @property
    def size_bytes(self) -> int:
        """Taille du payload en octets."""
        return self.data.numel() * self.data.element_size()

    def mark_sent(self) -> None:
        self.status = PacketStatus.IN_TRANSIT
        self.t_sent = time.perf_counter()

    def mark_received(self) -> None:
        self.status = PacketStatus.COMPUTING
        self.t_received = time.perf_counter()

    def mark_done(self, result: Optional[torch.Tensor] = None) -> None:
        self.status = PacketStatus.DONE
        self.t_done = time.perf_counter()
        if result is not None:
            self.result = result

    def mark_stolen(self, new_target: int) -> None:
        self.status = PacketStatus.STOLEN
        self.gpu_target = new_target

    @property
    def compute_time(self) -> float:
        """T_calcul mesuré (s) — 0 si non terminé."""
        if self.t_done > 0 and self.t_received > 0:
            return self.t_done - self.t_received
        return 0.0

    @property
    def transfer_time(self) -> float:
        """T_transfert mesuré (s) — 0 si non applicable."""
        if self.t_received > 0 and self.t_sent > 0:
            return self.t_received - self.t_sent
        return 0.0


class PacketPool:
    """Pool global de packets, thread-safe (deque + Lock)."""

    def __init__(self) -> None:
        self._queue: Deque[Packet] = deque()
        self._lock = threading.Lock()
        self._total_created: int = 0
        self._total_stolen: int = 0

    # ------------------------------------------------------------------
    def put(self, packet: Packet) -> None:
        """Ajoute un packet au pool."""
        with self._lock:
            self._queue.append(packet)
            self._total_created += 1

    def get(self) -> Optional[Packet]:
        """Retire le prochain packet (FIFO) ou None si vide."""
        with self._lock:
            if not self._queue:
                return None
            return self._queue.popleft()

    def steal_from(self, other: "PacketPool") -> Optional[Packet]:
        """Work stealing : prend un packet d'un autre pool.

        Verrouille les deux pools dans un ordre déterministe (par id)
        pour éviter tout deadlock.
        """
        if other is self:
            return self.get()
        first, second = (
            (self, other) if id(self) < id(other) else (other, self)
        )
        with first._lock:
            with second._lock:
                if not other._queue:
                    return None
                pkt = other._queue.pop()  # dernier = pas encore transféré
                pkt.mark_stolen(pkt.gpu_target)
                self._queue.append(pkt)
                self._total_stolen += 1
                return pkt

    # ------------------------------------------------------------------
    def __len__(self) -> int:
        with self._lock:
            return len(self._queue)

    @property
    def total_created(self) -> int:
        with self._lock:
            return self._total_created

    @property
    def total_stolen(self) -> int:
        with self._lock:
            return self._total_stolen

    def clear(self) -> None:
        with self._lock:
            self._queue.clear()
