"""Utilitaires KINVI-DIST : pinned memory, formatage, chronométrage."""

from __future__ import annotations

import time
from contextlib import contextmanager
from typing import Iterator

import torch


def pinned_empty_like(tensor: torch.Tensor) -> torch.Tensor:
    """Alloue une copie CPU en pinned memory d'un tensor."""
    out = torch.empty_like(tensor, device="cpu")
    if torch.cuda.is_available():
        out = out.pin_memory()
    return out


def ensure_pinned(tensor: torch.Tensor) -> torch.Tensor:
    """Garantit qu'un tensor CPU est en pinned memory (obligatoire en transit)."""
    if tensor.is_cuda or tensor.is_pinned() or not torch.cuda.is_available():
        return tensor
    return tensor.pin_memory()


def format_bytes(n: float) -> str:
    """Formate des octets en chaîne lisible (MB, GB…)."""
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while n >= 1024 and i < len(units) - 1:
        n /= 1024.0
        i += 1
    return f"{n:.1f} {units[i]}"


def format_bw(bytes_per_s: float) -> str:
    """Formate une bande passante en chaîne lisible."""
    return f"{format_bytes(bytes_per_s)}/s"


def format_ms(seconds: float) -> str:
    """Formate des secondes en millisecondes lisibles."""
    return f"{seconds * 1e3:.1f} ms"


@contextmanager
def timer() -> Iterator[callable]:
    """Contexte de chronométrage : ``with timer() as t: ... ; t()`` → secondes."""
    t0 = time.perf_counter()
    yield lambda: time.perf_counter() - t0
