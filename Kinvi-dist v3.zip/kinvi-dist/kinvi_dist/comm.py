"""MODULE 6 — Communication inter-GPU.

Backend NVLink (peer-to-peer direct) si détecté, sinon PCIe via
pinned memory CPU + cudaMemcpyAsync. Tout transfert est non-bloquant ;
la synchronisation se fait uniquement via CUDA Events.

Gestion erreurs : timeout 30 s par packet, 3 retransmissions max,
heartbeat worker toutes les 500 ms, mort déclarée après 2 s de silence.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, Optional

import torch

from .packet import Packet
from .profiler import GPUProfiler

PACKET_TIMEOUT_S: float = 30.0
MAX_RETRIES: int = 3
HEARTBEAT_PERIOD_S: float = 0.5
HEARTBEAT_DEAD_AFTER_S: float = 2.0


@dataclass
class TransferHandle:
    """Handle d'un transfert asynchrone (CUDA Event de fin)."""

    packet: Packet
    event: Optional["torch.cuda.Event"] = None
    t_start: float = field(default_factory=time.perf_counter)

    def is_done(self) -> bool:
        """Non-bloquant : True si le transfert est terminé."""
        if self.event is None:
            return True  # mode CPU : transfert synchrone déjà fini
        return bool(self.event.query())

    def wait(self, timeout: float = PACKET_TIMEOUT_S) -> bool:
        """Bloque jusqu'à fin de transfert ou timeout. Retourne succès."""
        if self.event is None:
            return True
        t0 = time.perf_counter()
        while not self.event.query():
            if time.perf_counter() - t0 > timeout:
                return False
            time.sleep(0.001)
        return True


class CommBackend:
    """Backend de communication NVLink / PCIe, 100 % non-bloquant."""

    def __init__(
        self,
        interconnect: str = "PCIe",
        profiler: Optional[GPUProfiler] = None,
    ) -> None:
        self.interconnect = interconnect
        self.profiler = profiler or GPUProfiler(0)
        self._streams: Dict[tuple, "torch.cuda.Stream"] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    def _stream_for(self, src: int, dst: int) -> Optional["torch.cuda.Stream"]:
        """Stream dédié par paire (src, dst) — jamais le stream par défaut."""
        if not torch.cuda.is_available():
            return None
        key = (src, dst)
        with self._lock:
            if key not in self._streams:
                self._streams[key] = torch.cuda.Stream(device=dst)
            return self._streams[key]

    # ------------------------------------------------------------------
    def send(
        self,
        packet: Packet,
        dst_device: int,
        src_device: int = -1,
    ) -> TransferHandle:
        """Lance un transfert non-bloquant vers ``dst_device``.

        NVLink : peer-to-peer direct ``tensor.to(device, non_blocking=True)``.
        PCIe : pinned memory CPU + copy async sur stream dédié.
        """
        packet.mark_sent()
        data = packet.data

        if not torch.cuda.is_available():
            # Mode CPU : copie immédiate, pas de stream.
            packet.data = data.clone()
            packet.mark_received()
            return TransferHandle(packet=packet, event=None)

        dst = torch.device(f"cuda:{dst_device}")
        stream = self._stream_for(src_device, dst_device)
        event = torch.cuda.Event()

        if data.is_cuda and self.interconnect == "NVLink":
            # Peer-to-peer direct.
            with torch.cuda.stream(stream):
                moved = data.to(dst, non_blocking=True)
                event.record(stream)
        else:
            # PCIe : pinned memory CPU intermédiaire obligatoire.
            host = data
            if data.is_cuda:
                host = torch.empty_like(data, device="cpu").pin_memory()
                host.copy_(data, non_blocking=True)
            elif not data.is_pinned():
                host = data.pin_memory()
            with torch.cuda.stream(stream):
                moved = host.to(dst, non_blocking=True)
                event.record(stream)

        packet.data = moved
        return TransferHandle(packet=packet, event=event)

    # ------------------------------------------------------------------
    def complete(self, handle: TransferHandle) -> bool:
        """Finalise un transfert : attente, métriques, retries (max 3).

        Après 3 échecs, retourne False → le Master reprend le chunk.
        """
        pkt = handle.packet
        while True:
            if handle.wait(timeout=PACKET_TIMEOUT_S):
                pkt.mark_received()
                self.profiler.record_transfer(
                    pkt.gpu_target, pkt.transfer_time or 1e-6, pkt.size_bytes
                )
                return True
            pkt.retry_count += 1
            if pkt.retry_count > MAX_RETRIES:
                return False  # le Master reprend le chunk
            # Retransmission automatique.
            handle = self.send(pkt, pkt.gpu_target)


class HeartbeatMonitor:
    """Heartbeats worker : signal toutes les 500 ms, mort après 2 s."""

    def __init__(self) -> None:
        self._last_seen: Dict[int, float] = {}
        self._lock = threading.Lock()

    def beat(self, gpu: int) -> None:
        """Enregistre un signal de vie du worker ``gpu``."""
        with self._lock:
            self._last_seen[gpu] = time.perf_counter()

    def is_alive(self, gpu: int) -> bool:
        """True si le worker a signalé dans les 2 dernières secondes."""
        with self._lock:
            last = self._last_seen.get(gpu)
        if last is None:
            return False
        return (time.perf_counter() - last) <= HEARTBEAT_DEAD_AFTER_S

    def dead_workers(self) -> list:
        """Liste des GPU silencieux depuis plus de 2 s."""
        now = time.perf_counter()
        with self._lock:
            return [
                g
                for g, last in self._last_seen.items()
                if now - last > HEARTBEAT_DEAD_AFTER_S
            ]

    def unregister(self, gpu: int) -> None:
        with self._lock:
            self._last_seen.pop(gpu, None)


class Redistributor:
    """Redistribue les packets d'un worker mort (callback Master)."""

    def __init__(self, on_redistribute: Callable[[int], None]) -> None:
        self.on_redistribute = on_redistribute

    def handle_dead(self, gpu: int) -> None:
        """Le Master reprend les chunks du GPU mort."""
        self.on_redistribute(gpu)
