"""MODULE 1 — Détection des GPU et matrice de bande passante.

Détecte tous les GPU via pynvml + torch.cuda, mesure la bande passante
réelle entre chaque paire de GPU au démarrage et stocke le résultat
dans une ``BandwidthMatrix``. GPU[0] = MASTER, le reste = WORKERS.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional

import torch

try:
    import pynvml  # type: ignore

    _PYNVML_OK = True
except Exception:  # pragma: no cover - dépend de la machine
    _PYNVML_OK = False


@dataclass
class GPUInfo:
    """Métadonnées d'un GPU détecté."""

    index: int
    name: str
    vram_total_bytes: int
    compute_capability: tuple
    interconnect: str = "PCIe"  # "NVLink" ou "PCIe"
    role: str = "WORKER"  # "MASTER" pour GPU 0


@dataclass
class BandwidthMatrix:
    """Matrice des bandes passantes mesurées (octets/s) entre paires de GPU.

    ``matrix[i][j]`` = bande passante mesurée de GPU i vers GPU j.
    La diagonale = bande passante mémoire locale approximative.
    """

    matrix: List[List[float]] = field(default_factory=list)

    def get(self, i: int, j: int) -> float:
        """Retourne la bande passante i→j en octets/s (0 si inconnue)."""
        try:
            return self.matrix[i][j]
        except IndexError:
            return 0.0

    def set(self, i: int, j: int, value: float) -> None:
        while len(self.matrix) <= max(i, j):
            self.matrix.append([0.0] * (max(i, j) + 1))
        for row in self.matrix:
            while len(row) <= max(i, j):
                row.append(0.0)
        self.matrix[i][j] = value


class GPUDetector:
    """Détecte les GPU et mesure la BandwidthMatrix de démarrage."""

    BENCH_TENSOR_BYTES: int = 512 * 1024**2  # 512 MB
    BENCH_DURATION_S: float = 0.100  # 100 ms

    def __init__(self) -> None:
        self.gpus: List[GPUInfo] = []
        self.bandwidth: BandwidthMatrix = BandwidthMatrix()
        if _PYNVML_OK:
            try:
                pynvml.nvmlInit()
            except Exception:
                pass

    # ------------------------------------------------------------------
    def detect(self) -> List[GPUInfo]:
        """Détecte tous les GPU CUDA disponibles.

        Returns:
            Liste de ``GPUInfo`` ; vide si aucun GPU (mode CPU).
        """
        self.gpus = []
        if not torch.cuda.is_available():
            return self.gpus

        count = torch.cuda.device_count()
        for i in range(count):
            props = torch.cuda.get_device_properties(i)
            info = GPUInfo(
                index=i,
                name=props.name,
                vram_total_bytes=props.total_memory,
                compute_capability=(props.major, props.minor),
                interconnect=self._detect_interconnect(i, count),
                role="MASTER" if i == 0 else "WORKER",
            )
            self.gpus.append(info)
        return self.gpus

    # ------------------------------------------------------------------
    def _detect_interconnect(self, index: int, count: int) -> str:
        """Détecte NVLink via pynvml si possible, sinon PCIe."""
        if _PYNVML_OK:
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(index)
                for link in range(6):
                    try:
                        state = pynvml.nvmlDeviceGetNvLinkState(handle, link)
                        if state:
                            return "NVLink"
                    except Exception:
                        break
            except Exception:
                pass
        # Heuristique : P2P accessible → souvent NVLink / P2P PCIe.
        if count > 1 and torch.cuda.is_available():
            try:
                peer = (index + 1) % count
                if torch.cuda.can_device_access_peer(index, peer):
                    return "NVLink"
            except Exception:
                pass
        return "PCIe"

    # ------------------------------------------------------------------
    def benchmark_bandwidth(self, gpus: Optional[List[GPUInfo]] = None) -> BandwidthMatrix:
        """Mesure la bande passante réelle entre chaque paire de GPU.

        Transfert d'un tensor de 512 MB, chronométré sur ~100 ms minimum.
        Remplit ``self.bandwidth``.
        """
        gpus = gpus if gpus is not None else self.gpus
        n = len(gpus)
        self.bandwidth = BandwidthMatrix(
            matrix=[[0.0 for _ in range(n)] for _ in range(n)]
        )
        if n == 0 or not torch.cuda.is_available():
            return self.bandwidth

        numel = self.BENCH_TENSOR_BYTES // 4  # float32
        for i in range(n):
            src = torch.randn(numel, device=f"cuda:{i}")
            for j in range(n):
                dst = (
                    src
                    if i == j
                    else torch.empty(numel, device=f"cuda:{j}")
                )
                torch.cuda.synchronize()
                t0 = time.perf_counter()
                elapsed = 0.0
                iters = 0
                while elapsed < self.BENCH_DURATION_S or iters < 2:
                    if i == j:
                        dst.copy_(src, non_blocking=True)
                    else:
                        dst.copy_(src, non_blocking=True)
                    torch.cuda.synchronize()
                    elapsed = time.perf_counter() - t0
                    iters += 1
                bw = (self.BENCH_TENSOR_BYTES * iters) / max(elapsed, 1e-9)
                self.bandwidth.set(i, j, bw)
                if i != j:
                    del dst
                    torch.cuda.empty_cache()
            del src
            torch.cuda.empty_cache()
        return self.bandwidth

    # ------------------------------------------------------------------
    @property
    def master(self) -> Optional[GPUInfo]:
        """Retourne le GPU MASTER (GPU 0) ou None."""
        return self.gpus[0] if self.gpus else None

    @property
    def workers(self) -> List[GPUInfo]:
        """Retourne la liste des GPU WORKERS."""
        return [g for g in self.gpus if g.role == "WORKER"]
