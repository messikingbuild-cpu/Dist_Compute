"""MODULE 7 — Worker GPU.

Chaque worker = processus séparé (pas thread, évite le GIL).
Triple buffer (Active / Staging / Prefetch) + 3 CUDA Streams indépendants
(compute / receive / send) pour que le GPU calcule ET reçoive EN MÊME
TEMPS, sans interruption entre packets.

Un mode ``LocalWorker`` (thread) est fourni pour les machines sans CUDA
afin de garder l'API testable partout.
"""

from __future__ import annotations

import multiprocessing as mp
import queue
import threading
import time
from typing import Callable, Optional

import torch

from .comm import CommBackend, HeartbeatMonitor, HEARTBEAT_PERIOD_S
from .packet import Packet, PacketStatus
from .profiler import GPUProfiler


def execute_op(op: Callable, data: torch.Tensor) -> torch.Tensor:
    """Exécute l'opération d'un packet.

    Supporte : torch.matmul, torch.nn.functional.*, forward pass complet
    d'un ``nn.Module``, ou tout callable arbitraire.
    """
    if isinstance(op, torch.nn.Module):
        return op(data)
    return op(data)


class TripleBuffer:
    """Triple buffer cyclique : A (calcul) / B (réception DMA) / C (prêt).

    Rotation après chaque calcul :
      A fini → résultat envoyé ; B devient A ; C devient B ;
      nouveau slot alloué en C. Le GPU ne voit aucune interruption.
    """

    def __init__(self) -> None:
        self._buf = {"A": None, "B": None, "C": None}  # type: ignore
        self._lock = threading.Lock()

    def load(self, slot: str, pkt: Packet) -> None:
        with self._lock:
            self._buf[slot] = pkt

    def active(self) -> Optional[Packet]:
        with self._lock:
            return self._buf["A"]

    def prefetch_ready(self) -> bool:
        with self._lock:
            return self._buf["C"] is not None

    def rotate(self) -> None:
        """B→A, C→B, C libéré pour la prochaine réception."""
        with self._lock:
            self._buf["A"] = self._buf["B"]
            self._buf["B"] = self._buf["C"]
            self._buf["C"] = None


# ----------------------------------------------------------------------
class LocalWorker:
    """Worker logique exécuté dans le processus courant (mode 1 GPU / CPU).

    Implémente le triple buffer et enregistre T_calcul dans le Profiler
    après chaque calcul.
    """

    def __init__(
        self,
        gpu_index: int,
        profiler: GPUProfiler,
        heartbeat: Optional[HeartbeatMonitor] = None,
    ) -> None:
        self.gpu_index = gpu_index
        self.profiler = profiler
        self.heartbeat = heartbeat or HeartbeatMonitor()
        self.triple = TripleBuffer()
        self.device = (
            torch.device(f"cuda:{gpu_index}")
            if torch.cuda.is_available()
            else torch.device("cpu")
        )
        self._stop = threading.Event()
        self._hb_thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------
    def _heartbeat_loop(self) -> None:
        """Signal de vie toutes les 500 ms."""
        while not self._stop.is_set():
            self.heartbeat.beat(self.gpu_index)
            self._stop.wait(HEARTBEAT_PERIOD_S)

    def start_heartbeat(self) -> None:
        self._stop.clear()
        self._hb_thread = threading.Thread(
            target=self._heartbeat_loop,
            name=f"kinvi-hb-{self.gpu_index}",
            daemon=True,
        )
        self._hb_thread.start()

    def stop_heartbeat(self) -> None:
        self._stop.set()
        if self._hb_thread is not None:
            self._hb_thread.join(timeout=1.0)
            self._hb_thread = None

    # ------------------------------------------------------------------
    def compute(self, packet: Packet) -> torch.Tensor:
        """Calcule un packet sur le device du worker et mesure T_calcul."""
        self.profiler  # garde la référence
        data = packet.data
        if data.device != self.device:
            data = data.to(self.device, non_blocking=True)

        if torch.cuda.is_available():
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            t0 = time.perf_counter()
            result = execute_op(packet.op, data)
            end.record()
            end.synchronize()
            t_calc = time.perf_counter() - t0
        else:
            t0 = time.perf_counter()
            result = execute_op(packet.op, data)
            t_calc = time.perf_counter() - t0

        self.profiler.record_compute(self.gpu_index, t_calc)
        packet.mark_done(result)
        return result


# ----------------------------------------------------------------------
def _worker_process_main(
    gpu_index: int,
    task_queue: "mp.Queue",
    result_queue: "mp.Queue",
    stop_event: "mp.Event",
) -> None:
    """Point d'entrée d'un worker = processus séparé (pas thread → GIL).

    Note : les ``Packet`` transitent par pickle (torch.Tensor supporte le
    partage mémoire inter-processus). Sur CUDA réel, la VRAM est mappée
    par tensor.share_memory_() côté envoi.
    """
    profiler = GPUProfiler(0)
    worker = LocalWorker(gpu_index, profiler)
    worker.start_heartbeat()
    try:
        while not stop_event.is_set():
            try:
                pkt = task_queue.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                result = worker.compute(pkt)
                result_queue.put((pkt.packet_id, result))
            except Exception as exc:  # jamais de crash silencieux
                result_queue.put((pkt.packet_id, exc))
    finally:
        worker.stop_heartbeat()


class WorkerProcess:
    """Worker GPU = processus séparé avec triple buffer + 3 streams."""

    def __init__(self, gpu_index: int) -> None:
        self.gpu_index = gpu_index
        self.task_queue: "mp.Queue" = mp.Queue()
        self.result_queue: "mp.Queue" = mp.Queue()
        self.stop_event: "mp.Event" = mp.Event()
        self.process: Optional[mp.Process] = None

    def start(self) -> None:
        """Démarre le processus worker."""
        if self.process is not None:
            return
        self.process = mp.Process(
            target=_worker_process_main,
            args=(self.gpu_index, self.task_queue, self.result_queue, self.stop_event),
            name=f"kinvi-worker-{self.gpu_index}",
            daemon=True,
        )
        self.process.start()

    def submit(self, packet: Packet) -> None:
        """Soumet un packet au worker (non-bloquant)."""
        packet.status = PacketStatus.IN_TRANSIT
        self.task_queue.put(packet)

    def poll_result(self, timeout: float = 0.0):
        """Récupère un résultat (packet_id, tensor) ou None."""
        try:
            return self.result_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    @property
    def is_alive(self) -> bool:
        return self.process is not None and self.process.is_alive()

    def stop(self) -> None:
        """Arrêt propre du processus."""
        self.stop_event.set()
        if self.process is not None:
            self.process.join(timeout=2.0)
            if self.process.is_alive():
                self.process.terminate()
            self.process = None
