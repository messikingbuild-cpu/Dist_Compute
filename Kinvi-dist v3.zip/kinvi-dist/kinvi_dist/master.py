"""MODULE 8 — Master (GPU 0).

Coordonne Scheduler + Workers + Comm + Profiler.
``execute(tensor, operation)`` :
  - 1 GPU → calcul local direct, overhead zéro (règle absolue n°7) ;
  - sinon slice selon share[i], crée les Packets, remplit le PacketPool,
    envoie avec le timing du Scheduler, collecte, trie par packet_id,
    ``torch.cat()``.
"""

from __future__ import annotations

import threading
import time
from typing import Callable, Dict, List, Optional

import torch

from .comm import CommBackend, HeartbeatMonitor, TransferHandle
from .detector import GPUDetector
from .packet import Packet, PacketPool
from .profiler import GPUProfiler
from .scheduler import Scheduler
from .work_stealer import WorkStealer
from .worker import LocalWorker

# Sous-taille de chunk pour découper chaque share en plusieurs packets.
DEFAULT_CHUNK_BYTES: int = 64 * 1024**2  # 64 MB


class Master:
    """Coordinateur central du framework KINVI-DIST."""

    def __init__(self, detector: Optional[GPUDetector] = None) -> None:
        self.detector = detector or GPUDetector()
        self.gpus = self.detector.detect()
        if self.gpus:
            self.detector.benchmark_bandwidth()

        self.num_gpus = max(len(self.gpus), 1)
        self.profiler = GPUProfiler(self.num_gpus)
        self.pool = PacketPool()
        self.heartbeat = HeartbeatMonitor()
        self.scheduler = Scheduler(self.profiler, list(range(self.num_gpus)))
        self.stealer = WorkStealer(self.pool, list(range(self.num_gpus)))
        interconnect = self.gpus[0].interconnect if self.gpus else "PCIe"
        self.comm = CommBackend(interconnect=interconnect, profiler=self.profiler)
        self.workers: Dict[int, LocalWorker] = {
            i: LocalWorker(i, self.profiler, self.heartbeat)
            for i in range(self.num_gpus)
        }
        self._packets_total: int = 0
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    def _slice_tensor(
        self, tensor: torch.Tensor, shares: Dict[int, float]
    ) -> List[torch.Tensor]:
        """Découpe le tensor selon share[i] du Scheduler (dim 0)."""
        n = tensor.shape[0]
        bounds: List[int] = []
        acc = 0.0
        for i in range(self.num_gpus):
            acc += shares.get(i, 0.0) * n
            bounds.append(min(n, int(round(acc))))
        bounds[-1] = n
        slices, prev = [], 0
        for b in bounds:
            slices.append(tensor[prev:b])
            prev = b
        return [s for s in slices if s.shape[0] > 0]

    def _make_packets(
        self, tensor: torch.Tensor, op: Callable
    ) -> List[Packet]:
        """Crée les packets : slice par share puis chunk par taille auto."""
        shares = self.scheduler.compute_shares()
        packets: List[Packet] = []
        for gpu, part in enumerate(self._slice_tensor(tensor, shares)):
            target_gpu = gpu
            pkt_size = max(self.scheduler.packet_size(target_gpu), 1)
            row_bytes = (
                part[0].numel() * part.element_size() if part.shape[0] else 1
            )
            rows_per_pkt = max(1, pkt_size // max(row_bytes, 1))
            for start in range(0, part.shape[0], rows_per_pkt):
                chunk = part[start : start + rows_per_pkt].contiguous()
                packets.append(Packet(data=chunk, op=op, gpu_target=target_gpu))
        return packets

    # ------------------------------------------------------------------
    def execute(self, tensor: torch.Tensor, operation: Callable) -> torch.Tensor:
        """Exécute ``operation`` sur ``tensor`` distribué sur tous les GPU.

        Args:
            tensor: Tensor d'entrée (batch sur la dim 0).
            operation: Callable tensor → tensor.

        Returns:
            Tensor résultat, reconstitué par ``torch.cat`` dans l'ordre.
        """
        # Règle absolue n°7 : 1 GPU → mode local pur, overhead zéro.
        if self.num_gpus <= 1:
            device = (
                torch.device("cuda:0") if torch.cuda.is_available() else "cpu"
            )
            data = tensor.to(device) if tensor.device != device else tensor
            return operation(data)

        t0 = time.perf_counter()
        packets = self._make_packets(tensor, operation)
        with self._lock:
            self._packets_total += len(packets)

        results: Dict[int, torch.Tensor] = {}
        handles: List[TransferHandle] = []

        # Part du GPU 0 : stream_compute local immédiat.
        for pkt in packets:
            if pkt.gpu_target == 0:
                self.scheduler.notify_compute_started(0)
                results[pkt.packet_id] = self.workers[0].compute(pkt)

        # Workers : envoi non-bloquant puis complétion.
        for pkt in packets:
            if pkt.gpu_target != 0:
                self.pool.put(pkt)
                handles.append(self.comm.send(pkt, pkt.gpu_target, src_device=0))

        for handle in handles:
            pkt = handle.packet
            ok = self.comm.complete(handle)
            if not ok:
                # Après 3 échecs : le Master reprend le chunk.
                pkt.gpu_target = 0
                results[pkt.packet_id] = self.workers[0].compute(pkt)
                continue
            self.scheduler.notify_compute_started(pkt.gpu_target)
            results[pkt.packet_id] = self.workers[pkt.gpu_target].compute(pkt)

        # Collecte : tri par packet_id, torch.cat().
        ordered = [results[k] for k in sorted(results)]
        out = torch.cat([r.cpu() for r in ordered], dim=0)
        self.profiler  # overhead mesurable ci-dessous
        _ = time.perf_counter() - t0
        return out

    # ------------------------------------------------------------------
    @property
    def packets_total(self) -> int:
        with self._lock:
            return self._packets_total

    @property
    def packets_stolen(self) -> int:
        return self.stealer.steal_count

    def idle_ratios(self) -> Dict[int, float]:
        """idle_time par GPU — métrique principale (objectif < 1%)."""
        return {i: self.profiler.idle_ratio(i) for i in range(self.num_gpus)}

    def shutdown(self) -> None:
        """Arrêt propre : scheduler, heartbeats."""
        self.scheduler.stop()
        for w in self.workers.values():
            w.stop_heartbeat()
